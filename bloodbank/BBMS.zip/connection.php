<?php
$servername = "localhost";
$username = "id20053996_root";
$password = "BBMSroot@123";
$dbname = "id20053996_bbms";

$connect = mysqli_connect($servername, $username, $password, $dbname);
 ?>
